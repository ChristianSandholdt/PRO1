package Model;

import java.util.ArrayList;

public class Participant {
    private String address;
    private String companyName;
    private String name;
    private int phoneNumber;
    private int companyPhoneNumber;
    private boolean isSpeaker;
    private final ArrayList<Registration> registrations = new ArrayList<>();

    public Participant(String name, String address, String companyName, int phoneNumber, int companyPhoneNumber, boolean isSpeaker){

        this.name = name;
        this.address = address;
        this.companyName = companyName;
        this.companyPhoneNumber = companyPhoneNumber;
        this.phoneNumber = phoneNumber;
        this.isSpeaker = isSpeaker;
    }

    public boolean isSpeaker() {
        return isSpeaker;
    }

    public void addRegistration(Registration registration){
        registrations.add(registration);
    }

    public String getName(){
        return name;
    }

    public String getCompanyName(){
        return companyName;
    }

    public String getAddress(){
        return address;
    }

    public int getCompanyPhoneNumber(){
        return companyPhoneNumber;
    }

    public int getPhoneNumber(){
        return phoneNumber;
    }

    public ArrayList<Registration> getRegistrations() {
        return registrations;
    }
}
