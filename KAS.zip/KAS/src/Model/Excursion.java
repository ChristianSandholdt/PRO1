package Model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Excursion {
    private LocalDateTime date;
    private String name;
    private Conference conference;
    private Boolean food;
    private Double price;
    private final ArrayList<Companion> companions = new ArrayList<>();

    public Excursion(LocalDateTime date, String name, boolean food, double price) {
        this.date = date;
        this.name = name;
        this.food = food;
        this.price = price;
    }

    public ArrayList<Companion> getCompanions() {
        return companions;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public Conference getConference() {
        return conference;
    }

    public String getName() {
        return name;
    }

    public Boolean getFood() {
        return food;
    }

    public Double getPrice() {
        return price;
    }

    public void addCompanion(Companion companion){
        companions.add(companion);
    }

    //Remove companion not coded, because there is no need for it
}

