package Model;

import java.util.ArrayList;

public class Companion {
    private String name;
    private int number;
    private ArrayList<Registration> registrations = new ArrayList<>();
    private ArrayList<Excursion> excursions = new ArrayList<>();

    public Companion(String name, int number, Registration registration) {
        this.name = name;
        this.number = number;
        registrations.add(registration);
    }

    public String getName() {
        return name;
    }

    public void addExcursions(Excursion excursion) {
        this.excursions.add(excursion);
    }

    public void removeExcursions(Excursion excursion) {
        this.excursions.remove(excursion);
    }

    public ArrayList<Registration> getRegistrations() {
        return registrations;
    }

    public int getNumber() {
        return number;
    }

    public double prisForExcursions() {
        int sum = 0;
        for (Excursion excursion : excursions) {
            sum += excursion.getPrice();
        }
        return sum;
    }
}
