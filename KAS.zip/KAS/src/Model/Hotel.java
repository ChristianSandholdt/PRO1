package Model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Hotel {
    private LocalDateTime timeOfArrival;
    private LocalDateTime timeOfDeparture;
    private String name;
    private double singleRoomPrice;
    private double doubleRoomPrice;

    private final ArrayList<Registration> registrations = new ArrayList<>();
    private final ArrayList<Supplement> supplements = new ArrayList<>();
    private final ArrayList<Conference> conferences = new ArrayList<>();

    public Hotel(String name, double singleRoomPrice, double doubleRoomPrice){
        this.name = name;
        this.singleRoomPrice = singleRoomPrice;
        this.doubleRoomPrice = doubleRoomPrice;
    }

    public LocalDateTime getTimeOfArrival(){
        return timeOfArrival;
    }

    public LocalDateTime getTimeOfDeparture(){
        return timeOfDeparture;
    }

    public String getName(){
        return name;
    }

    public double getPrice(boolean doubleRoom) {
        return (doubleRoom ? doubleRoomPrice : singleRoomPrice);
    }

    public ArrayList<Registration> getRegistrations() {
        return registrations;
    }

    public ArrayList<Supplement> getSupplements() {
        return supplements;
    }

    public void addSup(Supplement sup) {
        supplements.add(sup);
    }

    public void addReg(Registration reg) {
        registrations.add(reg);
    }

    public ArrayList<Conference> getConferences() {
        return conferences;
    }
}
