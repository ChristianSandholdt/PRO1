package Model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Conference {
    private String name;
    private double pricePerDay;
    private LocalDateTime start, end;

    private ArrayList<Registration> registrations = new ArrayList<>();
    private ArrayList<Excursion> excursions = new ArrayList<>();
    private ArrayList<Hotel> hotels = new ArrayList<>();

    public Conference(String name, int price, LocalDateTime start, LocalDateTime end) {
        this.name = name;
        this.pricePerDay = price;
        this.start = start;
        this.end = end;
    }
    public ArrayList<Registration> getRegistrations() {
        return registrations;
    }
    public ArrayList<Excursion> getExcursions() {
        return excursions;
    }
    public ArrayList<Hotel> getHotels() {
        return hotels;
    }

    public void addRegistration(Registration registration) {
        registrations.add(registration);
        registration.setCon(this);
    }
    public void addExcursion(Excursion excursion) {
        excursions.add(excursion);
    }
    public void addHotel(Hotel hotel) {
        hotels.add(hotel);
    }

    public void printRegs() {
        for (Registration reg : getRegistrations()) {
            Participant par = reg.getParticipant();
            System.out.println("========================================================");
            System.out.printf("%-17s %s\n","Name: ",par.getName());
            System.out.printf("%-17s %d\n","Phone number: ",par.getPhoneNumber());
            if(reg.getCompanion() != null) System.out.printf("%-17s %s\n","Companion name: ",reg.getCompanion().getName());
            System.out.printf("%-17s %s\n","Speaker: ",par.isSpeaker());
        }
    }

    public void printExcs() {
        for (Excursion excursion : getExcursions()) {
            System.out.println("========================================================");
            System.out.printf("%-17s %s\n","Name: ",excursion.getName());
            int d = 0;
            for (Companion companion : excursion.getCompanions()) {
                for (Registration registration : companion.getRegistrations()) {
                    System.out.printf("%-17s %s (%s %d)\n","Companion: ",companion.getName(),registration.getParticipant().getName(),registration.getParticipant().getPhoneNumber());
                }

            }
        }
    }

    public void printHots() {
        for (Hotel hotel : getHotels()) {
            System.out.println("========================================================");
            System.out.printf("%-17s %s\n","Name: ",hotel.getName());

            for (Registration reg : hotel.getRegistrations()) {
                System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - -");
                    System.out.printf("%-17s %s %s\n","Participant: ",reg.getParticipant().getName(),(reg.getCompanion() != null ? "(" + reg.getCompanion().getName() + ")" : ""));
                    System.out.printf("%-17s %s \n","PhoneNumber: ",reg.getParticipant().getPhoneNumber());
                    System.out.printf("%-17s %s days \n","Duration: ",reg.getDuration());
                    for(Supplement supplement : reg.getSup()) {
                        System.out.println("supplements");
                        System.out.printf("%-17s %s %s dkk.\n"," - ",supplement.getName(),supplement.getPrice());
                }
            }
        }
    }

    public String getName() {
        return name;
    }

    public double getPricePerDay() {
        return pricePerDay;
    }
}
