package Model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Registration {

    private int duration;
    private boolean doubleRoom;
    private Participant participant;
    private Companion companion;
    private Hotel hotel;
    private LocalDateTime time;
    private Conference conference;

    private final ArrayList<Excursion> excursions = new ArrayList<>();
    private final ArrayList<Supplement> supplements = new ArrayList<>();

    public Registration(Participant participant, int duration){
        this.participant = participant;
        this.duration = duration;
        this.time = LocalDateTime.now();
    }

    public Participant getParticipant() {
        return participant;
    }

    public Companion getCompanion() {
        return companion;
    }

    public Hotel getHot() {
        return hotel;
    }

    public void setHot(Hotel hot, boolean doubleRoom) {
        this.hotel = hot;
        this.doubleRoom = doubleRoom;
    }

    public void setCom(Companion companion) {
        this.companion = companion;
    }

    public Conference getConference() {
        return conference;
    }

    public ArrayList<Supplement> getSup() {
        return supplements;
    }

    public void addSup(Supplement sup) {
        supplements.add(sup);
    }

    public void setCon(Conference con) {
        conference = con;
    }

    public void addExc(Excursion exc) {
        excursions.add(exc);
    }

    public void removeExc(Excursion exc) {
        excursions.remove(exc);
    }

    public int getDuration() {
        return duration;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public double totalPrice() {
        int sum = 0;
        if(hotel != null)  sum += hotel.getPrice(doubleRoom) * (duration - 1);
        for (Supplement supplement : supplements) {
            sum += supplement.getPrice() * (duration - 1);
        }
        for (Excursion excursion : excursions) {
            sum += excursion.getPrice();
        }
        if(participant.getCompanyName() == null && !participant.isSpeaker()) {
            sum += conference.getPricePerDay() * duration;
        }

        return sum;
    }

    public void printOut() {
        String Q = "25";

        System.out.println("========================================================");
        System.out.printf("%-"+Q+"s %s\n","Participant:", participant.getName());
        if(companion != null) System.out.printf("%-"+Q+"s %s\n", "Companion:", companion.getName());
        System.out.printf("%-"+Q+"s %d\n","Phone No.:", participant.getPhoneNumber());
        System.out.printf("%-"+Q+"s %-17d days\n","Stay duration:", duration);
        if(companion != null) {
            System.out.print("Excursions:\n");
            for (Excursion excursion : excursions) {
                System.out.printf("%-"+Q+"s %-17.2f dkk.\n", " - " + excursion.getName(), excursion.getPrice());
            }
        }

        if(participant.getCompanyName() != null) System.out.printf("company %s",participant.getCompanyName());
        if(hotel != null) {
            System.out.printf("%-"+Q+"s %-17.2f dkk.\n",hotel.getName() + ":",hotel.getPrice(doubleRoom));
            System.out.print("Supplements:\n");
            for (Supplement supplement : supplements) {
                System.out.printf("%-"+Q+"s %-17.2f dkk\n", " - " + supplement.getName(), supplement.getPrice());
            }
        }
        System.out.print("Conference:\n");
        if(participant.getCompanyName() == null && !participant.isSpeaker()) {
            System.out.printf("%-"+Q+"s %-17.2f dkk.\n", " - " + conference.getName(), conference.getPricePerDay());
        } else {
            System.out.printf("%-"+Q+"s %-17.2f dkk.\n", " - " + conference.getName(), 0.);
        }
        System.out.printf("%-"+Q+"s %-17.2f dkk.\n","Samlet price:",totalPrice());
    }
}
