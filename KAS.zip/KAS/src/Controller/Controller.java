package Controller;


import Model.*;
import Storage.Storage;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Controller {

    /**
     * Creates a conference and adds it to storage.
     * pre: name != null, price > 0, start & end times set.
     */
    public static Conference createCon(String name, int price, LocalDateTime start, LocalDateTime end) {
        Conference con = new Conference(name, price, start, end);
        Storage.conferences.add(con);
        return con;
    }

    /**
     * Creates a Hotel and adds it to storage.
     * pre: name != null, room > 0.
     */
    public static Hotel createHot(String name, double singleRoomPrice, double doubleRoomPrice) {
        Hotel hotel = new Hotel(name, singleRoomPrice, doubleRoomPrice );
        Storage.hotels.add(hotel);
        return hotel;
    }
    public static Excursion createExc(LocalDateTime date, String name, boolean food, double price) {
        return new Excursion(date, name, food, price);
    }
    public static Companion createCom(String name, int number, Registration registration){
        Companion comp = new Companion(name,number,registration);
        Storage.companions.add(comp);
        return comp;
    }
    public static Participant createPar(String name, String address, String companyName, int phoneNumber, int companyPhoneNumber, boolean isSpeaker){
        Participant parti = new Participant(name,address, companyName, phoneNumber, companyPhoneNumber, isSpeaker);
        Storage.participants.add(parti);
        return parti;
    }

    public static Registration createReg(Participant participant, int duration){
        Registration registration = new Registration(participant, duration);
        participant.addRegistration(registration);
        return registration;
    }
    public static Supplement createSup(String name, double price, Hotel hot) {
        Supplement Sup = new Supplement(name, price);
        hot.addSup(Sup);
        return Sup;
    }

    // ------------------------ TO CON  --------------------------

    public static void addHot(Conference con, Hotel hotel){
        con.addHotel(hotel);
    }
    public static void addExc(Conference con, Excursion exc) {
        con.addExcursion(exc);
    }
    public static void addReg(Conference con, Registration reg) {
        con.addRegistration(reg);
    }


    // ------------------------ TO REG ---------------------------

    public static void setHot(Registration registration, Hotel hotel, boolean doubleRoom){
        registration.setHot(hotel, doubleRoom);
        hotel.addReg(registration);
    }
    public static void setCom(Registration registration, Companion com){
        registration.setCom(com);
    }
    public static void addExc(Registration registration, Excursion exc){
        registration.addExc(exc);
        exc.addCompanion(registration.getCompanion());
    }
    public static void addSup(Registration registration, Supplement sup) {
        registration.addSup(sup);
    }

    public static ArrayList<Registration> getRegistrations(Participant participant) {
        return participant.getRegistrations();
    }
}
