package GUI;

import Model.Participant;
import Model.Registration;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.util.ArrayList;

public class ConList {
    private static final StackPane stackPane = new StackPane();
    public static StackPane get(Participant participant) {
        GridPane gridPane = new GridPane();

        Text text = new Text("LIST");
        text.setFill(Color.GOLD);
        text.setFont(Font.font(null, FontWeight.BOLD,28));

        StackPane topBar = new StackPane();
        topBar.getChildren().add(text);
        topBar.setBackground(new Background(new BackgroundFill(Color.color(50/255.,60/255.,60/255.), CornerRadii.EMPTY, Insets.EMPTY)));

        gridPane.setGridLinesVisible(true);
        gridPane.add(topBar,0,0,GUI.elementsX,1);

        ArrayList<Button> buttons = new ArrayList<>();

        for (Registration registration : participant.getRegistrations()) {
            Button button = new Button(registration.getConference().getName());
            button.setOnAction((event) -> {
                stackPane.getChildren().remove(GUI.fredPane);
                button.getScene().setRoot(Info.get(registration));
            });
            button.setMaxSize(Double.MAX_VALUE,40);
            button.setAlignment(Pos.CENTER);
            buttons.add(button);
        }

        VBox vBox = new VBox();
        vBox.getChildren().addAll(buttons);
        vBox.setAlignment(Pos.CENTER);

        ScrollPane scrollPane = new ScrollPane(vBox);

        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        gridPane.add(scrollPane,2,2,5,7);
        GridPane.setHalignment(scrollPane, HPos.CENTER);

        RowConstraints row1 = new RowConstraints();
        RowConstraints row2 = new RowConstraints();
        row1.setMinHeight(50);
        row2.setMinHeight(50);

        for (int x = 0; x < GUI.elementsX; x++) {
            gridPane.getColumnConstraints().add(GUI.col1);
        }

        gridPane.getRowConstraints().add(row1);
        gridPane.getRowConstraints().add(row1);
        gridPane.getRowConstraints().add(row1);
        gridPane.getRowConstraints().add(row1);
        gridPane.getRowConstraints().add(row1);
        gridPane.getRowConstraints().add(row1);
        gridPane.getRowConstraints().add(row1);

        stackPane.setBackground(new Background(new BackgroundFill(Color.color(0/255.,100/255.,100/255.), CornerRadii.EMPTY, Insets.EMPTY)));
        stackPane.getChildren().addAll(GUI.fredPane,gridPane);
        return stackPane;
    }
}