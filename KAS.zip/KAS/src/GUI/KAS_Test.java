package GUI;

import Controller.Controller;
import Model.*;

import java.time.LocalDateTime;

public class KAS_Test {
    static Conference oneCon = Controller.createCon("Hav & Himmel",1500, LocalDateTime.now(), LocalDateTime.now());
    static Conference TwoCon = Controller.createCon("Hav & Himmel",1500, LocalDateTime.now(), LocalDateTime.now());
    static Conference ThreeCon = Controller.createCon("Hav & Himmel",1500, LocalDateTime.now(), LocalDateTime.now());
    static Conference FourCon = Controller.createCon("bad & Himmel",1500, LocalDateTime.now(), LocalDateTime.now());

    static Hotel Svane = Controller.createHot("Den Hvide Svane", 1050, 1250);
    static Hotel Phønix = Controller.createHot("Phønix", 700, 800);
    static Hotel Tusindfryd = Controller.createHot("TusindFryd", 500, 500);

    static Supplement wifi = Controller.createSup("WIFI", 50, Svane);

    static Excursion Odense = Controller.createExc(LocalDateTime.now(), "Byrundtur Odense", false, 125.);
    static Excursion Egeskov = Controller.createExc(LocalDateTime.now(), "Egeskov", false, 75.);
    static Excursion Trapholdt = Controller.createExc(LocalDateTime.now(), "Trapholdt Museum", false, 200);

    static Participant finn = Controller.createPar("Finn Madsen",   "Vinkelvej 69",null,26226761, 0, false);
    static Participant nils = Controller.createPar("Nils Petersen", "Vinkelvej 69",null,26226762, 0, false);
    static Participant ulla = Controller.createPar("Ulla Hansen",   "Vinkelvej 69",null,26226763, 0, false);
    static Participant peter = Controller.createPar("Peter Sommer", "Vinkelvej 69",null,26226764, 0, false);
    static Participant lone = Controller.createPar("Lone Jensen",   "Vinkelvej 69",null,26226765, 0, true);

    static Registration reg1 = Controller.createReg(finn, 3);
    static Registration reg2 = Controller.createReg(nils, 3);
    static Registration reg3 = Controller.createReg(ulla, 2);
    static Registration reg4 = Controller.createReg(peter, 3);
    static Registration reg5 = Controller.createReg(lone, 3);

    static Companion hans = Controller.createCom("Hans Hansen", reg3.getParticipant().getPhoneNumber(),reg3);
    static Companion mie = Controller.createCom("Mie Sommer",reg4.getParticipant().getPhoneNumber(), reg4);
    static Companion jan = Controller.createCom("Jan Madsen",reg4.getParticipant().getPhoneNumber(), reg5);

    public static void runTest() {
        Controller.setHot(reg2, Svane, false);

        Controller.setCom(reg3,hans);
        Controller.addExc(reg3,Odense);

        Controller.setHot(reg4,Svane,true);
        Controller.setCom(reg4,mie);
        Controller.addExc(reg4,Egeskov);
        Controller.addExc(reg4,Trapholdt);
        Controller.addSup(reg4,wifi);

        Controller.setHot(reg5, Svane, true);
        Controller.setCom(reg5, jan);
        Controller.addExc(reg5,Egeskov);
        Controller.addExc(reg5,Odense);
        Controller.addSup(reg5,wifi);

        Controller.addReg(oneCon, reg1);
        Controller.addReg(oneCon, reg2);
        Controller.addReg(oneCon, reg3);
        Controller.addReg(oneCon, reg4);
        Controller.addReg(oneCon, reg5);

        Controller.addHot(oneCon, Svane);
        Controller.addHot(oneCon, Phønix);
        Controller.addHot(oneCon, Tusindfryd);

        Controller.addExc(oneCon, Odense);
        Controller.addExc(oneCon, Egeskov);
        Controller.addExc(oneCon, Trapholdt);

        for (Registration registration : oneCon.getRegistrations()) {
            registration.printOut();
        }

        System.out.println("========================================================");
        System.out.println("\n\n\nRegistrations:");
        oneCon.printRegs();
        System.out.println("========================================================");
        System.out.println("\n\n\nExcursions:");
        oneCon.printExcs();
        System.out.println("========================================================");
        System.out.println("\n\n\nHotelList:");
        oneCon.printHots();
        System.out.println("========================================================");
    }
}
