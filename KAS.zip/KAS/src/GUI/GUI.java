package GUI;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.Arrays;

public class GUI extends Application {
    public static double sceneWidth = 800;
    public static double sceneHeight = 700;
    public static final int elementsX = 9;
    public static final int elementsY = 3;
    public static final ColumnConstraints col1 = new ColumnConstraints();
    public static final RowConstraints center = new RowConstraints();

    @Override
    public void start(Stage stage) {
        col1.setPercentWidth((GUI.sceneWidth / GUI.elementsX * 100 / GUI.sceneWidth));
        center.setPercentHeight(((GUI.sceneHeight / 2 - 50 - 50) / GUI.sceneHeight) * 100);

        Scene scene = new Scene(Login.get(),sceneWidth,sceneHeight);
        scene.setCamera(new PerspectiveCamera(false));
        stage.setScene(scene);
        stage.setTitle("KAS");
        stage.show();
        stage.widthProperty().addListener((obs,oV,nV) -> {
            sceneWidth = (double) nV;
            Platform.runLater(() -> col1.setPercentWidth((sceneWidth / elementsX * 100 / sceneWidth)));
        });
        stage.heightProperty().addListener((obs,oV,nV) -> {
            sceneHeight = (double) nV;
            Platform.runLater(() -> center.setPercentHeight(((sceneHeight / 2 - 50 - 50) / sceneHeight) * 100));
        });
    }





    public static Pane fredPane = extraMagic();

    private static double rotate = 0;
    private static Pane extraMagic() {
        Rectangle[] rectangle = new Rectangle[3];

        for (int i = 0; i < rectangle.length; i++) {
            rectangle[i] = new Rectangle(0,0,120,20);
            rectangle[i].setTranslateX(100 - 120/2. + 50 * Math.cos(Math.toRadians(120 * i)));
            rectangle[i].setTranslateY(100 - 20/2. + 50 * Math.sin(Math.toRadians(120 * i)));
            rectangle[i].setRotate(120 * i);
        }

        Shape triad = Shape.union(Shape.union(rectangle[0],rectangle[1]),rectangle[2]);
        Shape halo = Shape.subtract(Shape.subtract(new Circle(100,100,100),triad),new Circle(100,100,80));
        Shape finalClip1 = Shape.union(halo, new Circle(100,100,60));
        Shape finalClip2 = Shape.union(halo, new Circle(100,100,60));

        Pane shadow = new Pane();
        shadow.setClip(finalClip1);
        shadow.setMaxSize(200, 200);
        shadow.setBackground(new Background(new BackgroundFill(Color.color(0/255.,110/255.,110/255.), CornerRadii.EMPTY, Insets.EMPTY)));
        shadow.setTranslateX(5);
        shadow.setTranslateY(5);

        Pane roller = new Pane(); // SHAPE
        roller.setClip(finalClip2);
        roller.setMaxSize(200, 200);
        roller.setBackground(new Background(new BackgroundFill(Color.color(0/255.,120/255.,120/255.), CornerRadii.EMPTY, Insets.EMPTY)));

        StackPane rotator = new StackPane();
        rotator.getChildren().addAll(roller);
        rotator.setScaleX(2);
        rotator.setScaleY(2);

        new Thread(() -> {
            while (true) {
                Platform.runLater(() -> {
                    roller.setRotate(rotate += .035);
                    shadow.setRotate(rotate += .035);
                });
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
        return rotator;
    }
}



