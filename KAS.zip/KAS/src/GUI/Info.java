package GUI;

import Model.Conference;
import Model.Registration;
import Storage.Storage;
import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.ListIterator;

public class Info {
    private static final TextField txfName = new TextField();
    private static final TextField txfPhoneNumber = new TextField();
    private static final TextField txfAddress = new TextField();
    private static final TextField txfCompanyName = new TextField();
    private static final TextField txfCompanyPhoneNumber = new TextField();
    private static final CheckBox cbSpeaker = new CheckBox();
    private static final CheckBox cbCompanion = new CheckBox();
    private static final TextField txfCompanionName = new TextField();
    private static final TextField txfExcursion = new TextField();
    private static final TextField txfHotel = new TextField();
    private static final TextField txfDuration = new TextField();
    private static final TextField txfSupplement = new TextField();
    private static final TextField txfTotalPrice = new TextField();
    private static final ComboBox<Object> c_bConference = new ComboBox<>();
    private static final int conferenceID = 0;

    public static StackPane get(Registration registration) {
        GridPane gridPane = new GridPane();

        Text text = new Text("INFO");
        text.setFill(Color.GOLD);
        text.setFont(Font.font(null, FontWeight.BOLD,28));

        StackPane topBar = new StackPane();
        topBar.getChildren().add(text);
        topBar.setBackground(new Background(new BackgroundFill(Color.color(50/255.,60/255.,60/255.), CornerRadii.EMPTY, Insets.EMPTY)));

        //gridPane.setGridLinesVisible(true);
        gridPane.add(topBar,0,0,GUI.elementsX,1);

        Label lblConference = new Label("Conference:");
        lblConference.setFont(Font.font(null,FontWeight.BOLD,14));
        lblConference.setTextFill(Color.GOLD);
        gridPane.add(lblConference, 0, 2,2,1);
        GridPane.setHalignment(lblConference, HPos.CENTER);
        gridPane.add(c_bConference, 2, 2, 2, 1);
        String i = "";
        for (Conference conference : Storage.conferences) {
            String extra = "";
            ListIterator<Object> cons = c_bConference.getItems().listIterator();
            while (cons.hasNext()) {
                if (cons.next().equals(conference.getName())) {
                    extra = " (" + i + ")";
                }
            }
            i += "I";
            System.out.println("A");
            c_bConference.getItems().add(conference + extra);
        }
        c_bConference.setOnAction(event -> {
            //Conference conference = (Conference) c_bConference.getValue();
            //System.out.println(conference.getName());
            //System.out.println(conference.getPricePerDay());
        });


        txfName.setText(registration.getParticipant().getName());
        Label lblName = new Label("Full name:");
        lblName.setFont(Font.font(null,FontWeight.BOLD,14));
        lblName.setTextFill(Color.GOLD);
        gridPane.add(lblName, 0, 4,2,1);
        GridPane.setHalignment(lblName, HPos.CENTER);
        gridPane.add(txfName, 2, 4, 2, 1);

        txfPhoneNumber.setText("" + registration.getParticipant().getPhoneNumber());
        Label lblPhoneNumber = new Label("Phone number:");
        lblPhoneNumber.setFont(Font.font(null,FontWeight.BOLD,14));
        lblPhoneNumber.setTextFill(Color.GOLD);
        gridPane.add(lblPhoneNumber, 4, 4,2,1);
        GridPane.setHalignment(lblPhoneNumber, HPos.CENTER);
        gridPane.add(txfPhoneNumber, 6, 4, 2, 1);

        txfAddress.setText(registration.getParticipant().getAddress());
        Label lblAddress = new Label("Address:");
        lblAddress.setFont(Font.font(null,FontWeight.BOLD,14));
        lblAddress.setTextFill(Color.GOLD);
        gridPane.add(lblAddress, 0, 6,2,1);
        GridPane.setHalignment(lblAddress, HPos.CENTER);
        gridPane.add(txfAddress, 2, 6, 2, 1);

        cbSpeaker.setText("Speaker:");
        cbSpeaker.setFont(Font.font(null,FontWeight.BOLD,14));
        cbSpeaker.setTextFill(Color.GOLD);
        gridPane.add(cbSpeaker, 6, 6,2,1);


        txfCompanyName.setText(registration.getParticipant().getCompanyName());
        Label lblCompanyName = new Label("Company:");
        lblCompanyName.setFont(Font.font(null,FontWeight.BOLD,14));
        lblCompanyName.setTextFill(Color.GOLD);
        gridPane.add(lblCompanyName, 0, 8,2,1);
        GridPane.setHalignment(lblCompanyName, HPos.CENTER);
        gridPane.add(txfCompanyName, 2, 8, 2, 1);

        txfCompanyPhoneNumber.setText("" + registration.getParticipant().getCompanyPhoneNumber());
        Label lblCompanyPN = new Label("Company-number:");
        lblCompanyPN.setFont(Font.font(null,FontWeight.BOLD,14));
        lblCompanyPN.setTextFill(Color.GOLD);
        gridPane.add(lblCompanyPN, 4, 8,2,1);
        GridPane.setHalignment(lblCompanyPN, HPos.CENTER);
        gridPane.add(txfCompanyPhoneNumber, 6, 8, 2, 1);

        cbCompanion.setText("Companion:");
        cbCompanion.setFont(Font.font(null,FontWeight.BOLD,14));
        cbCompanion.setTextFill(Color.GOLD);
        gridPane.add(cbCompanion, 2, 10,2,1);
        cbCompanion.setOnAction(event -> {
            Platform.runLater(()->{
                txfCompanionName.setDisable(!cbCompanion.isSelected());
                txfExcursion.setDisable(!cbCompanion.isSelected());
            });

        });

        Label lblCompanion = new Label("Companion name:");
        lblCompanion.setFont(Font.font(null,FontWeight.BOLD,14));
        lblCompanion.setTextFill(Color.GOLD);
        gridPane.add(lblCompanion, 0, 12,2,1);
        GridPane.setHalignment(lblCompanion, HPos.CENTER);
        gridPane.add(txfCompanionName, 2, 12, 2, 1);
        txfCompanionName.setDisable(true);

        Label lblExcursion = new Label("Excursion(s):");
        lblExcursion.setFont(Font.font(null,FontWeight.BOLD,14));
        lblExcursion.setTextFill(Color.GOLD);
        gridPane.add(lblExcursion, 0, 14,2,1);
        GridPane.setHalignment(lblExcursion, HPos.CENTER);
        gridPane.add(txfExcursion, 2, 14, 2, 1);
        txfExcursion.setDisable(true);


        //Hotel
        Label lblHotel = new Label("Hotels:");
        lblHotel.setFont(Font.font(null,FontWeight.BOLD,14));
        lblHotel.setTextFill(Color.GOLD);
        gridPane.add(lblHotel,0,16,2,1);
        GridPane.setHalignment(lblHotel, HPos.CENTER);
        gridPane.add(txfHotel, 2, 16, 2, 1);


        //Duration
        Label lblDuration = new Label("Duration:");
        lblDuration.setFont(Font.font(null,FontWeight.BOLD,14));
        lblDuration.setTextFill(Color.GOLD);
        gridPane.add(lblDuration,4,16,2,1);
        GridPane.setHalignment(lblDuration, HPos.CENTER);
        gridPane.add(txfDuration, 6, 16, 2, 1);


        //Supplement
        Label lblSupplement = new Label("Supplement(s):");
        lblSupplement.setFont(Font.font(null,FontWeight.BOLD,14));
        lblSupplement.setTextFill(Color.GOLD);
        gridPane.add(lblSupplement,0,18,2,1);
        GridPane.setHalignment(lblSupplement, HPos.CENTER);
        gridPane.add(txfSupplement, 2, 18, 4, 1);

        //Total price
        Label lblTotalPrice = new Label("Total Price:");
        lblTotalPrice.setFont(Font.font(null,FontWeight.BOLD,14));
        lblTotalPrice.setTextFill(Color.GOLD);
        gridPane.add(lblTotalPrice,0,20,2,1);
        GridPane.setHalignment(lblTotalPrice, HPos.CENTER);
        gridPane.add(txfTotalPrice, 2, 20, 1, 1);

        RowConstraints row1 = new RowConstraints();
        RowConstraints row2 = new RowConstraints();
        row1.setMinHeight(50);
        row2.setMinHeight(25);

        for (int x = 0; x < GUI.elementsX; x++) {
            gridPane.getColumnConstraints().add(GUI.col1);
        }

        gridPane.getRowConstraints().add(row1);
        gridPane.getRowConstraints().addAll(row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2,row2);

        StackPane stackPane = new StackPane();
        stackPane.setBackground(new Background(new BackgroundFill(Color.color(0/255.,100/255.,100/255.), CornerRadii.EMPTY, Insets.EMPTY)));
        stackPane.getChildren().addAll(GUI.fredPane,gridPane);
        return stackPane;
    }
}