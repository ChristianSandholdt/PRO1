package GUI;

import Storage.Storage;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Login {
    private static final StackPane stackPane = new StackPane();
    public static StackPane get() {
        GridPane gridPane = new GridPane();

        Text text = new Text("LOGIN");
        text.setFill(Color.GOLD);
        text.setFont(Font.font(null, FontWeight.BOLD,28));

        StackPane topBar = new StackPane();
        topBar.getChildren().add(text);
        topBar.setBackground(new Background(new BackgroundFill(Color.color(50/255.,60/255.,60/255.), CornerRadii.EMPTY, Insets.EMPTY)));

        Label lUsername = new Label("USERNAME:\t");
        lUsername.setFont(Font.font(null,FontWeight.BOLD,20));
        lUsername.setTextFill(Color.GOLD);

        Label lPassword = new Label("PASSWORD:\t");
        lPassword.setFont(Font.font(null,FontWeight.BOLD,20));
        lPassword.setTextFill(Color.GOLD);

        TextField tfUsername = new TextField();
        TextField tfPassword = new TextField();
        tfUsername.setMinHeight(30);
        tfPassword.setMinHeight(30);

        Button bLogin = new Button("LOGIN");
        bLogin.setOnAction(event -> {
            stackPane.getChildren().remove(GUI.fredPane);
            bLogin.getScene().setRoot(ConList.get(Storage.participants.get(4)));
        });
        bLogin.setMaxSize(Double.MAX_VALUE,40);

        //gridPane.setGridLinesVisible(true);
        gridPane.add(topBar,0,0,GUI.elementsX,1);
        gridPane.add(lUsername,2,2,2,1); gridPane.add(tfUsername,4,2,3,1);
        gridPane.add(lPassword,2,3,2,1); gridPane.add(tfPassword,4,3,3,1);
        gridPane.add(bLogin,3,4,3,1);

        GridPane.setHalignment(lUsername, HPos.CENTER);
        GridPane.setHalignment(lPassword, HPos.CENTER);

        RowConstraints row1 = new RowConstraints();
        RowConstraints row2 = new RowConstraints();
        row1.setMinHeight(50);
        row2.setMinHeight(50);

        for (int x = 0; x < GUI.elementsX; x++) {
            gridPane.getColumnConstraints().add(GUI.col1);
        }

        gridPane.getRowConstraints().add(row1);
        gridPane.getRowConstraints().add(GUI.center);
        gridPane.getRowConstraints().add(row2);
        gridPane.getRowConstraints().add(row2);
        gridPane.getRowConstraints().add(row2);
        gridPane.getRowConstraints().add(row2);

        stackPane.setBackground(new Background(new BackgroundFill(Color.color(0/255.,100/255.,100/255.), CornerRadii.EMPTY, Insets.EMPTY)));
        stackPane.getChildren().addAll(GUI.fredPane,gridPane);
        return stackPane;
    }
}