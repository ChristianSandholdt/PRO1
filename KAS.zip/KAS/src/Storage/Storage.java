package Storage;

import Model.*;

import java.util.ArrayList;

public class Storage {
    public static final ArrayList<Conference>   conferences   = new ArrayList<>();
    public static final ArrayList<Hotel>        hotels        = new ArrayList<>();
    public static final ArrayList<Participant>  participants  = new ArrayList<>();
    public static final ArrayList<Companion>    companions    = new ArrayList<>();
}
