package Project1.pigs;

public class PigsApp {

    public static void main(String[] args) {
        PigGame game = new PigGame();
        System.out.println("Welcome to the game of pigs.");
        game.play();

        System.out.println("Thank you for playing craps.");
    }
}
